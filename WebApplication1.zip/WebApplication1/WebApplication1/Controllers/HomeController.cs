﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace WebApplication1.Controllers
{
	public class HomeController : Controller
	{

		public HomeController(){}

		public ActionResult Index()
		{
			//ViewBag.GGYY = _ganGGYY.Test();  
			return View();
		}

		public ActionResult About()
		{
			return View();
		}

		public ActionResult Contact()
		{
			ViewBag.ConnStr1 = ConfigurationManager.ConnectionStrings["BackContext"].ConnectionString;
			return View();
		}

		public class CustomExceptionFilter : FilterAttribute,
		IExceptionFilter
		{
			public void OnException(ExceptionContext filterContext)
			{
				//filterContext.Result = new RedirectResult("customErrorPage.html");
				var res = new JsonResult
				{
					Data = new { success = false, error = filterContext.Exception.Message.ToString().Replace("\r", "").Replace("\n", "") },
					JsonRequestBehavior = JsonRequestBehavior.AllowGet
				};
				filterContext.ExceptionHandled = true;
				//filterContext.HttpContext.Response.Headers.Remove("Server");
				//filterContext.HttpContext.Response.Headers.Remove("X-AspNet-Version");
				//filterContext.HttpContext.Response.Headers.Remove("X-AspNetMvc-Version");
				filterContext.HttpContext.Response.StatusCode = 500;
				
				filterContext.Result = res;
				//狀態碼參考
				//https://www.zhihu.com/question/58686782
				//過濾器
				//http://kevintsengtw.blogspot.com/2014/02/aspnet-mvc-response-headers.html

			}
		}
	}
}
