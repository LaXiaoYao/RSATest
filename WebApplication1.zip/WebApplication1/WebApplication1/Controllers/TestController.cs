﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
	public class TestController : Controller
	{
		// GET: Test
		public ActionResult Index()
		{
			//var conn = ConfigurationManager.ConnectionStrings["BackContext"].ConnectionString;
			//var cmd = new SqlConnection(conn);
			ViewBag.Tables = ListTables();
			return View();
		}



		public IList<string> ListTables()
		{
			List<string> tables = new List<string>();
			var conn = ConfigurationManager.ConnectionStrings["BackContext"].ConnectionString;
			var _connection = new SqlConnection(conn);
			_connection.Open();
			DataTable dt = _connection.GetSchema("Tables");
			foreach (DataRow row in dt.Rows)
			{
				string tablename = (string)row[2];
				tables.Add(tablename);
				var txt = new StringBuilder();
				var queryString = $@"select top 1 * from [dbo].[{tablename}] ";
				SqlCommand command = new SqlCommand(queryString, _connection);
				var metaDataList = new List<IDictionary<String, Object>>();

				txt.AppendLine("using System;");
				txt.AppendLine("using Dapper;");
				txt.AppendLine("namespace WebApplication1.Entities");
				txt.AppendLine("{");
				txt.AppendLine(@"	[Table(" + '"' + tablename + '"' + ")]");
				txt.AppendLine($@"	public class {tablename} : EntityIdentify");
				txt.AppendLine(@"	{");
				SqlDataReader reader = command.ExecuteReader();

				if (tablename == "Video")
				{

				}
				var hasRows = reader.HasRows;
				while (reader.Read())
				{
					for (int i = 0; i < reader.FieldCount; i++)
					{
						dynamic fieldMetaData = new ExpandoObject();
						var columnName = reader.GetName(i);
						var value = reader[i];
						var dotNetType = reader.GetFieldType(i);
						var sqlType = reader.GetDataTypeName(i);
						var specificType = reader.GetProviderSpecificFieldType(i);

                        fieldMetaData.columnName = columnName;
						fieldMetaData.value = value;
						fieldMetaData.dotNetType = dotNetType;
						fieldMetaData.sqlType = sqlType;
						fieldMetaData.specificType = specificType;
						metaDataList.Add(fieldMetaData);
						
						if (i == 0)
						{
							txt.AppendLine($@"		private {dotNetType} _id;");
							txt.AppendLine(@"		[Column(" + '"' + columnName + '"' + ")]");
							txt.AppendLine($@"		public override {dotNetType} Id");
							txt.AppendLine(@"		{");
							txt.AppendLine(@"			get { return _id; }");
							txt.AppendLine(@"			set { _id = value; }");
							txt.AppendLine(@"		}");

						}
						else
						{
							txt.AppendLine($@"		public {dotNetType} {columnName}" + " { get; set; }");
						}

					}
				}
				txt.AppendLine("	}");

				txt.AppendLine("}");
				CrateEntity($@"/TT/EntityTest/{tablename}.cs", txt.ToString());
				reader.Close();
			}

			return tables;
		}


		public void CrateEntity(string fullPath, string txt)
		{
			string path = Server.MapPath(fullPath);


			FileStream fileStream = new FileStream(path, FileMode.Create);

			fileStream.Close();   //切記開了要關,不然會被佔用而無法修改喔!!!

			using (StreamWriter sw = new StreamWriter(path))
			{
				// 欲寫入的文字資料 ~
				sw.Write(txt);
			}
		}
	}
}