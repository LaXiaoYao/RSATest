﻿//using System.Configuration;
//using System.Reflection;
//using System.Web.Http;
//using System.Web.Mvc;
//using Autofac;
//using Autofac.Integration.Mvc;
//using WebApplication1.Repositories;
//using WebApplication1.UOW;

//namespace WebApplication1.App_Start
//{
//	/// <summary>
//	/// DI設定檔
//	/// </summary>
//	public class AutofacConfig
//	{
//		/// <summary>
//		/// 註冊DI注入物件資料
//		/// </summary>
//		public static void Register()
//		{
//			// 容器建立者
//			ContainerBuilder builder = new ContainerBuilder();

//			// 註冊Controllers
//			builder.RegisterControllers(Assembly.GetExecutingAssembly());

//			// 註冊DbContextFactory
//			string connectionString =
//				ConfigurationManager.ConnectionStrings["BackContext"].ConnectionString;
//			builder.RegisterType<DbContextFactory>()
//				.WithParameter("BackContext", connectionString)
//				.As<IDbContextFactory>()
//				.InstancePerHttpRequest();

//			// 註冊 Repository UnitOfWork
//			builder.RegisterGeneric(typeof(GenericRepository<>)).As(typeof(IRepository<>));
//			builder.RegisterType(typeof(UnitOfWork)).As(typeof(IUnitOfWork));

//			// 註冊Services
//			builder.RegisterAssemblyTypes(Assembly.GetExecutingAssembly())
//				   .Where(t => t.Name.EndsWith("Services"))
//				   .AsImplementedInterfaces();

//			// 建立容器
//			IContainer container = builder.Build();

//			// 解析容器內的型別
//			AutofacWebApiDependencyResolver resolverApi = new AutofacWebApiDependencyResolver(container);
//			AutofacDependencyResolver resolver = new AutofacDependencyResolver(container);

//			// 建立相依解析器
//			GlobalConfiguration.Configuration.DependencyResolver = resolverApi;
//			DependencyResolver.SetResolver(resolver);
//		}
//	}
//}

//unit of work di
//https://dotblogs.com.tw/mantou1201/2014/06/13/145527

//詳細流程講解
//https://dotblogs.com.tw/gelis/2014/09/08/146492
//https://dotblogs.com.tw/gelis/archive/2013/11/21/130795.aspx


